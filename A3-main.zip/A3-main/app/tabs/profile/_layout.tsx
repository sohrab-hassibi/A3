import { Stack } from "expo-router";
import { StyleSheet } from "react-native";

export default function ProfileLayout() {
  return (
    <Stack>{/* TODO: Add Stack.Screen components for each screen */}</Stack>
  );
}

// TODO: Create styles your layout here
const styles = StyleSheet.create({});
