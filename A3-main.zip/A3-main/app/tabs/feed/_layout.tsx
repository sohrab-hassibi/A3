import { Stack } from "expo-router";
import { StyleSheet } from "react-native";

export default function FeedLayout() {
  return (
    <Stack>{/* TODO: Add Stack.Screen components for each screen */}</Stack>
  );
}

// TODO: Create styles for your layout here
const styles = StyleSheet.create({});
