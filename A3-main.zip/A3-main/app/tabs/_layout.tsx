import { Tabs } from "expo-router";
import { StyleSheet } from "react-native";

export default function TabsLayout() {
  return (
    <Tabs screenOptions={{ lazy: false }}>
      {/* TODO: Add Tabs.Screen components for each tab and match the header/footers to the spec */}
    </Tabs>
  );
}

// TODO: Create styles your layout here
const styles = StyleSheet.create({});
