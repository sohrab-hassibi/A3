import db from "./db";

export { db };